
# coding: utf-8

# ### Code to create the data in USGS Data Release:
# # North American Bat Monitoring Program (NABat) Master Sample and Grid-Based Sampling Frame
# ###### The data created by this script is found here: **https://doi.org/10.5066/P9O75YDV**
# 
# Description:  
# > The NABat sampling frame is a grid-based finite-area frame spanning Canada, the United States, and Mexico consisting of N total number of 10- by 10-km (100-km2) grid cell sample units for the continental United States, Canada, and Alaska and 5- by 5-km (25km2) for Hawaii and Puerto Rico. This grain size is biologically appropriate given the scale of movement of most bat species, which routinely travel many kilometers each night between roosts and foraging areas and along foraging routes. A Generalized Random-Tessellation Stratified (GRTS) Survey Design draw was added to the sample units from the raw sampling grids (https://doi.org/10.5066/P9M00P17). This sampling design produces an ordered list of units such that any ordered subset of that list is also randomized and spatially balanced.
# 
# Citaion:  
# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *Talbert, C., and Reichert, B., 2018, North American Bat Monitoring Program (NABat) Master Sample and Grid-Based Sampling Frame: U.S. Geological Survey data release, https://doi.org/https://doi.org/10.5066/P9O75YDV.*

# ### Import the libraries we'll use

# In[1]:


import geopandas as gpd


# ### Reference the local data files we'll be using to attribute the GRTS ID

# In[2]:


# This is the sampling frame from USGS Data Release: https://doi.org/10.5066/P9O75YDV
conus_fname = r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\RawGrids\Conus\conus_mastersample_10km.shp"

# This shapefile contains the GRTs IDs we need to add to our layer.
orig_fname = r"N:\GISData\Active\Brown_GIS_WebApps\bpd\grts\master_sample\complete_conus_mastersample_10km.shp"

# This is the file name and path to save the output to.
out_fname = r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\GridsWithGRTS\Conus\conus_mastersample_10km_GRTS.shp"


# #### Read in our datasets

# In[3]:


conus = gpd.read_file(conus_fname)
orig_grts = gpd.read_file(orig_fname)


# ##### Make sure they have the same number of rows, and a common field we can link them with.

# In[4]:


conus.shape, orig_grts.shape


# In[5]:


conus.head()


# In[6]:


orig_grts.head()


# ### Join them with Pandas

# In[7]:


joined = conus.join(orig_grts.set_index('CONUS_10KM'), on='CONUS_10KM', lsuffix='orig', how='left')
joined.head()


# ### Cleanup the extraneous columns and set column type.

# In[8]:


out = joined[['CONUS_10KM', 'lat', 'long', 'GRTS_ID']]

conus['GRTS_ID'] = out.GRTS_ID.astype('int')
conus.sort_values('GRTS_ID', inplace=True)
conus.drop('CONUS_50KM', axis=1, inplace=True)
conus.head()


# #### This was not included in the final release but shows how to calculate the percentage value of the GRTs ID

# In[9]:


# conus['GRTS_PCNT'] = ((conus.GRTS_ID-1)/max(conus.GRTS_ID)*100).astype("int")+1
# conus.drop('GRTS_PCNT', axis=1, inplace=True)


# ### Save our output.

# In[10]:



conus.to_file(r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\GridsWithGRTS\Conus\conus_mastersample_10km_GRTS.shp")


# In[11]:


conus['pdpcnt'] = ((conus.GRTS_ID.rank(pct=True)*100).astype("int"))


# In[12]:


conus['pcnt'] = ((conus.GRTS_ID-1)/max(conus.GRTS_ID)*100).astype("int")+1


# In[13]:


conus.head()

