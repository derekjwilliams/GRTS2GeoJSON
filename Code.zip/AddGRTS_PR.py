
# coding: utf-8

# ### Code to create the data in USGS Data Release:
# # North American Bat Monitoring Program (NABat) Master Sample and Grid-Based Sampling Frame
# ###### The data created by this script is found here: **https://doi.org/10.5066/P9O75YDV**
# 
# Description:  
# > The NABat sampling frame is a grid-based finite-area frame spanning Canada, the United States, and Mexico consisting of N total number of 10- by 10-km (100-km2) grid cell sample units for the continental United States, Canada, and Alaska and 5- by 5-km (25km2) for Hawaii and Puerto Rico. This grain size is biologically appropriate given the scale of movement of most bat species, which routinely travel many kilometers each night between roosts and foraging areas and along foraging routes. A Generalized Random-Tessellation Stratified (GRTS) Survey Design draw was added to the sample units from the raw sampling grids (https://doi.org/10.5066/P9M00P17). This sampling design produces an ordered list of units such that any ordered subset of that list is also randomized and spatially balanced.
# 
# Citaion:  
# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *Talbert, C., and Reichert, B., 2018, North American Bat Monitoring Program (NABat) Master Sample and Grid-Based Sampling Frame: U.S. Geological Survey data release, https://doi.org/https://doi.org/10.5066/P9O75YDV.*

# ### Import the libraries we'll use

# In[1]:


import geopandas as gpd


# ### Reference the local data files we'll be using to attribute the GRTS ID

# In[2]:


# This is the sampling frame from USGS Data Release: https://doi.org/10.5066/P9O75YDV
fname = r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\RawGrids\PR\PR_mastersample_5km.shp"

# This is the file name and path to save the output to.
out_fname = r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\GridsWithGRTS\PR\PR_mastersample_10km_GRTS.shp"


# In[5]:


gdf = gpd.read_file(fname)


# In[6]:


gdf.head()


# In[16]:


points = gdf.copy()
points.geometry = points['geometry'].centroid
# same crs
points.crs = gdf.crs
points.head()


# In[13]:


#gdf.to_file(fname.replace('.shp', '_centroids.shp'))


# In[17]:


points.to_file(fname.replace('.shp', '_centroids.shp'))


# In[18]:


print(fname.replace('.shp', '_centroids.shp'))


# In[7]:


point_fname = r"C:\temp\PR\PR_mastersample_5km_centroids_grts2.shp"


# In[8]:


points = gpd.read_file(point_fname)


# In[23]:


points['GRTS_ID'] = points.index + 1


# In[32]:


gdf['GRTS_ID'] = gdf.join(points.set_index('PR_5KM'), on='PR_5KM', rsuffix='_p')['GRTS_ID_p']


# In[36]:


gdf.sort_values(['GRTS_ID'], inplace=True)
gdf.to_file(fname.replace('.shp', '_GRTs.shp'))

