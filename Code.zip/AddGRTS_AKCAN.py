
# coding: utf-8

# In[1]:


import geopandas as gpd


# In[2]:


akcan_fname = r"C:\temp\AKCAN\akcan_mastersample_10km.shp"
orig_fname = r"N:\GISData\Active\Brown_GIS_WebApps\bpd\bpd-847\FWS_Region1_GRTS30_Overlap\v101\master_sample_ak_can\master_sample_ak_canada_grid_grts_10km.shp"
out_fname = r"C:\temp\AKCAN\akcan_mastersample_10km_GRTS.shp"


# In[3]:


orig_fname = r"N:\GISData\Active\Brown_GIS_WebApps\bpd\bpd-847\FWS_Region1_GRTS30_Overlap\v101\master_sample_ak_can\AK_CAN_GRTS_Excel_10km.xlsx"


# In[6]:


import pandas as pd
orig_grts = pd.read_excel(orig_fname, sheet_name='Sheet1')


# In[7]:


orig_grts.head()


# In[8]:


akcan = gpd.read_file(akcan_fname)


# In[6]:


# orig_grts = gpd.read_file(orig_fname)


# In[9]:


akcan.shape, orig_grts.shape


# In[10]:


akcan.head()


# In[11]:


orig_grts['AKCAN_10KM'] = orig_grts['AKCAN10KM_']
orig_grts.head()


# In[12]:


joined = akcan.join(orig_grts.set_index('AKCAN_10KM'), 
                    on='AKCAN_10KM', lsuffix='orig', how='left')
joined.head()


# In[23]:


out = joined[['AKCAN_10KM', 'lat', 'long', 'GRTS_ID']]

akcan['GRTS_ID'] = out.GRTS_ID.astype('int')
akcan.sort_values('GRTS_ID', inplace=True)
try:
    akcan.drop('AKCAN_50KM', axis=1, inplace=True)
except:
    pass
akcan.head()


# In[24]:


# akcan['GRTS_PCNT'] = ((akcan.GRTS_ID-1)/max(akcan.GRTS_ID)*100).astype("int")+1
# akcan


# In[ ]:


akcan.drop('GRTS_PCNT', axis=1, inplace=True)
akcan.to_file(r"Z:\TSH\DD274_NABat\SamplingGrid\DATA\DERIVED\GridsWithGRTS\AKCAN\akcan_mastersample_10km_GRTS.shp")

